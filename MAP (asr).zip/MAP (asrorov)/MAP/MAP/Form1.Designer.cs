﻿namespace MAP
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelp5 = new System.Windows.Forms.Label();
            this.labelp4 = new System.Windows.Forms.Label();
            this.labelp3 = new System.Windows.Forms.Label();
            this.labelp2 = new System.Windows.Forms.Label();
            this.labelp1 = new System.Windows.Forms.Label();
            this.zagolovok = new System.Windows.Forms.Label();
            this.place = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStart1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxMedical = new System.Windows.Forms.PictureBox();
            this.pictureBoxInformation = new System.Windows.Forms.PictureBox();
            this.pictureBoxTuilets = new System.Windows.Forms.PictureBox();
            this.pictureBoxEnergy = new System.Windows.Forms.PictureBox();
            this.pictureBoxDrinks = new System.Windows.Forms.PictureBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureDelete = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTuilets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnergy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDrinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDelete)).BeginInit();
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(10, 5);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(77, 36);
            this.back.TabIndex = 1;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(992, 49);
            this.label1.TabIndex = 2;
            this.label1.Text = "Интерактивная карта";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelp5
            // 
            this.labelp5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelp5.Location = new System.Drawing.Point(771, 434);
            this.labelp5.Name = "labelp5";
            this.labelp5.Size = new System.Drawing.Size(217, 45);
            this.labelp5.TabIndex = 34;
            this.labelp5.Text = "Мед-пункт";
            this.labelp5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelp5.Visible = false;
            // 
            // labelp4
            // 
            this.labelp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelp4.Location = new System.Drawing.Point(772, 371);
            this.labelp4.Name = "labelp4";
            this.labelp4.Size = new System.Drawing.Size(217, 45);
            this.labelp4.TabIndex = 32;
            this.labelp4.Text = "Информация";
            this.labelp4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelp4.Visible = false;
            // 
            // labelp3
            // 
            this.labelp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelp3.Location = new System.Drawing.Point(771, 305);
            this.labelp3.Name = "labelp3";
            this.labelp3.Size = new System.Drawing.Size(217, 45);
            this.labelp3.TabIndex = 30;
            this.labelp3.Text = " Уборная";
            this.labelp3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelp3.Visible = false;
            // 
            // labelp2
            // 
            this.labelp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelp2.Location = new System.Drawing.Point(770, 231);
            this.labelp2.Name = "labelp2";
            this.labelp2.Size = new System.Drawing.Size(217, 45);
            this.labelp2.TabIndex = 28;
            this.labelp2.Tag = "";
            this.labelp2.Text = "Пункт зарядки";
            this.labelp2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelp2.Visible = false;
            // 
            // labelp1
            // 
            this.labelp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelp1.Location = new System.Drawing.Point(770, 162);
            this.labelp1.Name = "labelp1";
            this.labelp1.Size = new System.Drawing.Size(217, 45);
            this.labelp1.TabIndex = 26;
            this.labelp1.Text = "Напитки";
            this.labelp1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelp1.Visible = false;
            // 
            // zagolovok
            // 
            this.zagolovok.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zagolovok.Location = new System.Drawing.Point(747, 58);
            this.zagolovok.Name = "zagolovok";
            this.zagolovok.Size = new System.Drawing.Size(191, 40);
            this.zagolovok.TabIndex = 39;
            this.zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // place
            // 
            this.place.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.place.Location = new System.Drawing.Point(699, 99);
            this.place.Name = "place";
            this.place.Size = new System.Drawing.Size(296, 39);
            this.place.TabIndex = 40;
            this.place.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::MAP.Properties.Resources.finish;
            this.pictureBox2.Location = new System.Drawing.Point(214, 66);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 96);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBoxStart2
            // 
            this.pictureBoxStart2.Image = global::MAP.Properties.Resources.map_icon_start;
            this.pictureBoxStart2.Location = new System.Drawing.Point(296, 557);
            this.pictureBoxStart2.Name = "pictureBoxStart2";
            this.pictureBoxStart2.Size = new System.Drawing.Size(62, 64);
            this.pictureBoxStart2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxStart2.TabIndex = 37;
            this.pictureBoxStart2.TabStop = false;
            this.pictureBoxStart2.Click += new System.EventHandler(this.pictureBoxStart2_Click);
            // 
            // pictureBoxStart3
            // 
            this.pictureBoxStart3.Image = global::MAP.Properties.Resources.map_icon_start;
            this.pictureBoxStart3.Location = new System.Drawing.Point(94, 296);
            this.pictureBoxStart3.Name = "pictureBoxStart3";
            this.pictureBoxStart3.Size = new System.Drawing.Size(62, 58);
            this.pictureBoxStart3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxStart3.TabIndex = 36;
            this.pictureBoxStart3.TabStop = false;
            this.pictureBoxStart3.Click += new System.EventHandler(this.pictureBoxStart3_Click);
            // 
            // pictureBoxStart1
            // 
            this.pictureBoxStart1.Image = global::MAP.Properties.Resources.map_icon_start;
            this.pictureBoxStart1.Location = new System.Drawing.Point(254, 89);
            this.pictureBoxStart1.Name = "pictureBoxStart1";
            this.pictureBoxStart1.Size = new System.Drawing.Size(61, 59);
            this.pictureBoxStart1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxStart1.TabIndex = 35;
            this.pictureBoxStart1.TabStop = false;
            this.pictureBoxStart1.Click += new System.EventHandler(this.pictureBoxStart1_Click);
            // 
            // pictureBoxMedical
            // 
            this.pictureBoxMedical.Image = global::MAP.Properties.Resources.map_icon_medical;
            this.pictureBoxMedical.Location = new System.Drawing.Point(700, 431);
            this.pictureBoxMedical.Name = "pictureBoxMedical";
            this.pictureBoxMedical.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxMedical.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxMedical.TabIndex = 33;
            this.pictureBoxMedical.TabStop = false;
            this.pictureBoxMedical.Visible = false;
            this.pictureBoxMedical.Click += new System.EventHandler(this.pictureBoxMedical_Click);
            // 
            // pictureBoxInformation
            // 
            this.pictureBoxInformation.Image = global::MAP.Properties.Resources.map_icon_information;
            this.pictureBoxInformation.Location = new System.Drawing.Point(700, 365);
            this.pictureBoxInformation.Name = "pictureBoxInformation";
            this.pictureBoxInformation.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxInformation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxInformation.TabIndex = 31;
            this.pictureBoxInformation.TabStop = false;
            this.pictureBoxInformation.Visible = false;
            this.pictureBoxInformation.Click += new System.EventHandler(this.pictureBoxInformation_Click);
            // 
            // pictureBoxTuilets
            // 
            this.pictureBoxTuilets.Image = global::MAP.Properties.Resources.map_icon_toilets;
            this.pictureBoxTuilets.Location = new System.Drawing.Point(700, 299);
            this.pictureBoxTuilets.Name = "pictureBoxTuilets";
            this.pictureBoxTuilets.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxTuilets.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTuilets.TabIndex = 29;
            this.pictureBoxTuilets.TabStop = false;
            this.pictureBoxTuilets.Visible = false;
            this.pictureBoxTuilets.Click += new System.EventHandler(this.pictureBoxTuilets_Click);
            // 
            // pictureBoxEnergy
            // 
            this.pictureBoxEnergy.Image = global::MAP.Properties.Resources.map_icon_energy_bars;
            this.pictureBoxEnergy.Location = new System.Drawing.Point(700, 228);
            this.pictureBoxEnergy.Name = "pictureBoxEnergy";
            this.pictureBoxEnergy.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxEnergy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEnergy.TabIndex = 27;
            this.pictureBoxEnergy.TabStop = false;
            this.pictureBoxEnergy.Visible = false;
            this.pictureBoxEnergy.Click += new System.EventHandler(this.pictureBoxEnergy_Click);
            // 
            // pictureBoxDrinks
            // 
            this.pictureBoxDrinks.Image = global::MAP.Properties.Resources.map_icon_drinks1;
            this.pictureBoxDrinks.Location = new System.Drawing.Point(700, 160);
            this.pictureBoxDrinks.Name = "pictureBoxDrinks";
            this.pictureBoxDrinks.Size = new System.Drawing.Size(65, 59);
            this.pictureBoxDrinks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDrinks.TabIndex = 25;
            this.pictureBoxDrinks.TabStop = false;
            this.pictureBoxDrinks.Visible = false;
            this.pictureBoxDrinks.Click += new System.EventHandler(this.pictureBoxDrinks_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Control;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button8.Image = global::MAP.Properties.Resources._8;
            this.button8.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button8.Location = new System.Drawing.Point(78, 230);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(61, 60);
            this.button8.TabIndex = 10;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Control;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button7.Image = global::MAP.Properties.Resources._7;
            this.button7.Location = new System.Drawing.Point(96, 408);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(60, 60);
            this.button7.TabIndex = 9;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.Image = global::MAP.Properties.Resources._6;
            this.button6.Location = new System.Drawing.Point(158, 513);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 60);
            this.button6.TabIndex = 8;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button5.Image = global::MAP.Properties.Resources._5;
            this.button5.Location = new System.Drawing.Point(364, 574);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(60, 60);
            this.button5.TabIndex = 7;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button4.Image = global::MAP.Properties.Resources._4;
            this.button4.Location = new System.Drawing.Point(622, 488);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(60, 60);
            this.button4.TabIndex = 6;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button3.Image = global::MAP.Properties.Resources._3;
            this.button3.Location = new System.Drawing.Point(460, 353);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 60);
            this.button3.TabIndex = 5;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.Image = global::MAP.Properties.Resources._2;
            this.button2.Location = new System.Drawing.Point(474, 238);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 60);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Image = global::MAP.Properties.Resources._1;
            this.button1.Location = new System.Drawing.Point(401, 65);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 60);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = global::MAP.Properties.Resources.map1;
            this.pictureBox1.Location = new System.Drawing.Point(2, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(696, 591);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureDelete
            // 
            this.pictureDelete.Image = global::MAP.Properties.Resources.kisspng_computer_icons_download_5b3c1f77d934b2_6534606515306668718897;
            this.pictureDelete.Location = new System.Drawing.Point(964, 51);
            this.pictureDelete.Name = "pictureDelete";
            this.pictureDelete.Size = new System.Drawing.Size(31, 27);
            this.pictureDelete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureDelete.TabIndex = 41;
            this.pictureDelete.TabStop = false;
            this.pictureDelete.Visible = false;
            this.pictureDelete.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1001, 633);
            this.Controls.Add(this.pictureDelete);
            this.Controls.Add(this.place);
            this.Controls.Add(this.zagolovok);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBoxStart2);
            this.Controls.Add(this.pictureBoxStart3);
            this.Controls.Add(this.pictureBoxStart1);
            this.Controls.Add(this.labelp5);
            this.Controls.Add(this.pictureBoxMedical);
            this.Controls.Add(this.labelp4);
            this.Controls.Add(this.pictureBoxInformation);
            this.Controls.Add(this.labelp3);
            this.Controls.Add(this.pictureBoxTuilets);
            this.Controls.Add(this.labelp2);
            this.Controls.Add(this.pictureBoxEnergy);
            this.Controls.Add(this.labelp1);
            this.Controls.Add(this.pictureBoxDrinks);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.back);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMedical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTuilets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnergy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDrinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDelete)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label labelp5;
        private System.Windows.Forms.PictureBox pictureBoxMedical;
        private System.Windows.Forms.Label labelp4;
        private System.Windows.Forms.PictureBox pictureBoxInformation;
        private System.Windows.Forms.Label labelp3;
        private System.Windows.Forms.PictureBox pictureBoxTuilets;
        private System.Windows.Forms.Label labelp2;
        private System.Windows.Forms.PictureBox pictureBoxEnergy;
        private System.Windows.Forms.Label labelp1;
        private System.Windows.Forms.PictureBox pictureBoxDrinks;
        private System.Windows.Forms.PictureBox pictureBoxStart1;
        private System.Windows.Forms.PictureBox pictureBoxStart3;
        private System.Windows.Forms.PictureBox pictureBoxStart2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label zagolovok;
        private System.Windows.Forms.Label place;
        private System.Windows.Forms.PictureBox pictureDelete;
    }
}

