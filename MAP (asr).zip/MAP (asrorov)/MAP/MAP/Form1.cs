﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MAP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Delete()
        {
            pictureBoxDrinks.Visible = false; 
            pictureBoxEnergy.Visible = false;
            pictureBoxTuilets.Visible = false; 
            pictureBoxInformation.Visible = false; 
            pictureBoxMedical.Visible = false;

            labelp1.Text = "";
            labelp2.Text = "";
            labelp3.Text = "";


        }
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

 

        private void button3_Click(object sender, EventArgs e)
        {
            Delete();
            zagolovok.Text = "Пункт 3";
            place.Text = "Метро Фрунзевская";

            pictureBoxInformation.Visible = true; pictureBoxInformation.Location = new Point(700, 160);
            labelp1.Visible = true; labelp1.Text = "Информация";

            pictureBoxEnergy.Visible = true; pictureBoxEnergy.Location = new Point(700, 230);
            labelp2.Visible = true; labelp2.Text = "Пункт зарядки";

            pictureBoxDrinks.Visible = true; pictureBoxDrinks.Location = new Point(700, 300);
            labelp3.Visible = true; labelp3.Text = "Напитки";

            pictureDelete.Visible = true;

        }


        private void button5_Click(object sender, EventArgs e)
        {
            Delete();
  
            zagolovok.Text = "Пункт 5";
            place.Text = "МИД";

            pictureBoxDrinks.Visible = true; pictureBoxDrinks.Location = new Point(700, 160);
            labelp1.Visible = true; labelp1.Text = "Напитки";

            pictureBoxEnergy.Visible = true; pictureBoxEnergy.Location = new Point(700, 230);
            labelp2.Visible = true; labelp2.Text = "Пункт зарядки";

            pictureBoxInformation.Visible = true; pictureBoxInformation.Location = new Point(700, 300);
            labelp3.Visible = true; labelp3.Text = "Информация";

            pictureDelete.Visible = true;
        }

        private void pictureBoxStart1_Click(object sender, EventArgs e)
        {
            zagolovok.Text = "Старт 1";
            place.Text = "Улица Лужники";
            pictureDelete.Visible = true;

            Delete();
        }


        private void pictureBoxStart3_Click(object sender, EventArgs e)
        {
            zagolovok.Text = "Старт 3";
            place.Text = "Стадион Лужники";
            pictureDelete.Visible = true;

            Delete();
        }

        private void pictureBoxStart2_Click(object sender, EventArgs e)
        {
            zagolovok.Text = "Старт 2";
            place.Text = "Садовое кольцо";
            pictureDelete.Visible = true;

            Delete();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Delete();
            zagolovok.Text = "Пункт 1";
            place.Text = "Метро Спортивная";


            pictureBoxInformation.Visible = true; pictureBoxInformation.Location = new Point(700,160);
            labelp1.Visible = true;  labelp1.Text = "Инфориация";

            pictureBoxDrinks.Visible = true; pictureBoxDrinks.Location = new Point(700, 230);
            labelp2.Visible = true;  labelp2.Text = "Напитки";

            pictureBoxTuilets.Visible = true; pictureBoxTuilets.Location = new Point(700, 300);
            labelp3.Visible = true;  labelp3.Text = "Уборная";

            pictureDelete.Visible = true;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Delete();
            zagolovok.Text = "Пункт 2";
            place.Text = "Метро Воробьевы горы";

            pictureBoxMedical.Visible = true; pictureBoxMedical.Location = new Point(700, 160);
            labelp1.Visible = true; labelp1.Text = "Медпункт";

            pictureBoxTuilets.Visible = true; pictureBoxTuilets.Location = new Point(700, 230);
            labelp2.Visible = true; labelp2.Text = "Уборная";

            pictureBoxDrinks.Visible = true; pictureBoxDrinks.Location = new Point(700, 300);
            labelp3.Visible = true; labelp3.Text = "Напитки";

            pictureDelete.Visible = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Delete();
            zagolovok.Text = "Пункт 4";
            place.Text = "Метро Парк культуры";

            pictureBoxTuilets.Visible = true; pictureBoxTuilets.Location = new Point(700, 160);
            labelp1.Visible = true; labelp1.Text = "Уборная";

            pictureBoxInformation.Visible = true; pictureBoxInformation.Location = new Point(700, 230);
            labelp2.Visible = true; labelp2.Text = "Информация";

            pictureBoxMedical.Visible = true; pictureBoxMedical.Location = new Point(700, 300);
            labelp3.Visible = true; labelp3.Text = "Медпункт";

            pictureDelete.Visible = true;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Delete();
            zagolovok.Text = "Пункт 6";
            place.Text = "Метро Киевская";

            pictureBoxInformation.Visible = true; pictureBoxInformation.Location = new Point(700, 160);
            labelp1.Visible = true; labelp1.Text = "Информация";

            pictureBoxTuilets.Visible = true; pictureBoxTuilets.Location = new Point(700, 230);
            labelp2.Visible = true; labelp2.Text = "Уборная";

            pictureBoxMedical.Visible = true; pictureBoxMedical.Location = new Point(700, 300);
            labelp3.Visible = true; labelp3.Text = "Медпункт";

            pictureDelete.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Delete();
            zagolovok.Text = "Пункт 7";
            place.Text = "Фрунзенская ТЭЦ";

            pictureBoxEnergy.Visible = true; pictureBoxEnergy.Location = new Point(700, 160);
            labelp1.Visible = true; labelp1.Text = "Пункт зарядки";

            pictureBoxDrinks.Visible = true; pictureBoxDrinks.Location = new Point(700, 230);
            labelp2.Visible = true; labelp2.Text = "Напитки";

            pictureBoxTuilets.Visible = true; pictureBoxTuilets.Location = new Point(700, 300);
            labelp3.Visible = true; labelp3.Text = "Уборная";

            pictureDelete.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Delete();
            zagolovok.Text = "Пункт 8";
            place.Text = "Метро МЦК Лужники";

            pictureBoxMedical.Visible = true; pictureBoxMedical.Location = new Point(700, 160);
            labelp1.Visible = true; labelp1.Text = "Медпункт";

            pictureBoxInformation.Visible = true; pictureBoxInformation.Location = new Point(700, 230);
            labelp2.Visible = true; labelp2.Text = "Информация";

            pictureBoxDrinks.Visible = true; pictureBoxDrinks.Location = new Point(700, 300);
            labelp3.Visible = true; labelp3.Text = "Напитки";

            pictureDelete.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            zagolovok.Text = "Старт | Финиш";
            place.Text = "";
            pictureDelete.Visible = true;
            Delete();


        }

        private void pictureBoxDrinks_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxEnergy_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxTuilets_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxInformation_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxMedical_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBoxDrinks.Visible = false;
            pictureBoxEnergy.Visible = false;
            pictureBoxTuilets.Visible = false;
            pictureBoxInformation.Visible = false;
            pictureBoxMedical.Visible = false;

            labelp1.Text = "";
            labelp2.Text = "";
            labelp3.Text = "";

            zagolovok.Text = "";
            place.Text = "";

            pictureDelete.Visible = false;

        }
    }
}
