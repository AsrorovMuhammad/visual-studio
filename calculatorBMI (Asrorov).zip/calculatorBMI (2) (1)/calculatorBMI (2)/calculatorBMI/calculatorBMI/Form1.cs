﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatorBMI
{
    public partial class Form1 : Form
    {
        float h, w, index;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            height.Text = null;
            weight.Text = null ;
            trackBar1.Value = 0;
            pictureBox1.Image = null;

        }

        private void weight_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.Снимокмуж;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.Снимокжен;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            h = Convert.ToInt32(height.Text);
            w = Convert.ToInt32(weight.Text);
            h /= 100;
            index = w / (h * h);
            label_index.Text = Convert.ToString(index) ;

            if (index < 18.5) {index = 5; label_otvet.Text = "недостаток вес"; }

            else if (index >= 18.5 && index <= 24.9) {index = 15; label_otvet.Text = "здоровый"; }

            else if (index >= 25 && index <= 29.9) { index = 25; label_otvet.Text = "избыток веса"; }

            else {index = 35; label_otvet.Text = "ожирение"; }

            trackBar1.Value = Convert.ToInt32(index);


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
